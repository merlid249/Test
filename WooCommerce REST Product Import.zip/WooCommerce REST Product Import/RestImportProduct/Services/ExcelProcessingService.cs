﻿using CsvHelper.Configuration;
using CsvHelper;
using RestImportPorducts.Models;
using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net.Http;

namespace RestImportPorducts.Services
{
    public class ExcelProcessingService : IExcelProcessingService
    {
        private readonly IRestApiService _restApiService;

        public ExcelProcessingService(IRestApiService restApiService)
        {
            _restApiService = restApiService;
        }
        public async Task<(List<ExcelProduct> SimpleProducts, List<ExcelProduct> VariableProducts)> ProcessCsvFile(string csvFilePath)
        {
            var simpleProducts = new List<ExcelProduct>();
            var variableProducts = new Dictionary<string, ExcelProduct>();  // Keyed by Parent SKU
            ExcelProduct currentParent = null;

            using (var reader = new StreamReader(csvFilePath))
            using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
                Delimiter = ",",
                BadDataFound = null,
            }))
            {
                var records = csv.GetRecords<ExcelProduct>();

                try
                {
                    foreach (var record in records)
                    {
                        // Simple product case
                        if (string.IsNullOrEmpty(record.Parent) && string.Equals(record.Type, "simple", StringComparison.OrdinalIgnoreCase))
                        {
                            simpleProducts.Add(record);
                        }
                        // Parent variable product case
                        else if (string.IsNullOrEmpty(record.Parent) && string.Equals(record.Type, "variable", StringComparison.OrdinalIgnoreCase))
                        {
                            currentParent = record;  // Store the parent
                            currentParent.Variations = new List<ExcelProduct>(); // Initialize variations list
                            variableProducts[record.SKU] = currentParent;
                        }
                        // Variation case (Parent is not empty)
                        else if (!string.IsNullOrEmpty(record.Parent) && string.Equals(record.Type, "variable", StringComparison.OrdinalIgnoreCase))
                        {
                            if (variableProducts.ContainsKey(record.Parent))
                            {
                                // Add the variation to the parent's variation list
                                variableProducts[record.Parent].Variations.Add(record);
                            }
                            else
                            {
                                // If the parent hasn't been added yet, add the variation to a new parent
                                currentParent = new ExcelProduct
                                {
                                    SKU = record.Parent,
                                    Variations = new List<ExcelProduct> { record }
                                };
                                variableProducts[record.Parent] = currentParent;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception($"Error processing CSV file: {ex.Message}", ex);
                }
            }

            return (simpleProducts, variableProducts.Values.ToList());
        }

    }
}
