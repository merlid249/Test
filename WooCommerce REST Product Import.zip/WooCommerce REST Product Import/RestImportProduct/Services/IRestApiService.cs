﻿using RestImportPorducts.Helpers;
using RestImportPorducts.Models;
using RestImportProduct.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RestImportPorducts.Services
{
    public interface IRestApiService
    {
        Task<Product> PostProductAsync(RestApiSettings apiSettings, Product product);
        Task<Product> UpdateProductAsync(RestApiSettings apiSettings, string productSku, Product updatedProduct);
        Task<MediaItem> GetExistingImageUrl(RestApiSettings apiSettings, string imageName);
        Task<ProductVariation> PostProductVariationAsync(RestApiSettings apiSettings, string productSku, ProductVariation variation);
        Task<ProductVariation> UpdateProductVariationAsync(RestApiSettings apiSettings, string productSku, string variationSku, ProductVariation updatedVariation);

        Task BatchCreateOrUpdateProductsAsync(RestApiSettings apiSettings, BatchProductRequest batchRequest);
        Task UpdateVariationProductOnBatchAsync(RestApiSettings apiSettings, string productSku, List<ProductVariation> variations);

        Task<(Dictionary<string, Product> SimpleProducts, Dictionary<string, ProductWithVariations> VariableProducts)> LoadExistingProductsAndVariationsAsync(RestApiSettings apiSettings);

        Task<List<ProductCategory>> GetProductCategoryAsync(RestApiSettings apiSettings);

        Task<ProductCategory> CreateProductCategoryAsync(RestApiSettings apiSettings, ProductCategory newCategory);

        Task<bool> DeleteProductAsync(RestApiSettings apiSettings, string productId, bool force = false);

        Task<bool> DeleteCategoryByIdAsync(RestApiSettings apiSettings, int categoryId);
    }
}
