﻿using RestImportPorducts.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestImportPorducts.Services
{
    public interface IExcelProcessingService
    {
        Task<(List<ExcelProduct> SimpleProducts, List<ExcelProduct> VariableProducts)> ProcessCsvFile(string csvFilePath);

    }
}
