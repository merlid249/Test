﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RestImportPorducts.Helpers;
using RestImportPorducts.Models;
using RestImportProduct.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static RestImportPorducts.Models.ProductVariation;
using static System.Net.Mime.MediaTypeNames;

namespace RestImportPorducts.Services
{
    public class ProductOrchestrationService : IProductOrchestrationService
    {
        private readonly IRestApiService _restApiService;
        private readonly ILogger<ProductOrchestrationService> _logger;
        private readonly RestApiSettings _restApiSettings;

        public ProductOrchestrationService(IRestApiService restApiService, ILogger<ProductOrchestrationService> logger, IOptions<RestApiSettings> apiSettings)
        {
            _restApiService = restApiService;
            _logger = logger;
            _restApiSettings = apiSettings.Value;
        }

         public async Task OrchestrateProductsAsync(List<ExcelProduct> simpleProducts, List<ExcelProduct> variableProducts)
        {
            _logger.LogInformation($"[{_restApiSettings.BaseUrl}] Starting orchestration for product processing.");

            try
            {
                // Fetch categories
                List<ProductCategory> existingCategories = await _restApiService.GetProductCategoryAsync(_restApiSettings);
                _logger.LogInformation($"[{_restApiSettings.BaseUrl}] Fetched {existingCategories.Count} categories.");

                // Load existing products
               var (existingSimpleProducts, existingVariableProducts) = await _restApiService.LoadExistingProductsAndVariationsAsync(_restApiSettings);
                //Dictionary<string, Product> existingSimpleProducts = new Dictionary<string, Product>();
               // Dictionary< string, ProductWithVariations > existingVariableProducts = new Dictionary<string, ProductWithVariations >();    
                _logger.LogInformation($"[{_restApiSettings.BaseUrl}] Loaded {existingSimpleProducts.Count} simple products and {existingVariableProducts.Count} variable products.");

                // Process products
                var operationResults = new ConcurrentBag<ProductOperationResult>();
                var processSimpleTask = ProcessSimpleProducts(simpleProducts, existingSimpleProducts, existingCategories, operationResults);
                var processVariableTask = ProcessVariableProducts(variableProducts, existingVariableProducts, existingCategories, operationResults);

                await Task.WhenAll(processSimpleTask, processVariableTask);

                // Log operation results with BaseUrl
                LogOperationResults(operationResults, _restApiSettings.BaseUrl);

                _logger.LogInformation($"[{_restApiSettings.BaseUrl}] Orchestration process completed.");
            }
            catch (Exception ex)
            {
                _logger.LogError($"[{_restApiSettings.BaseUrl}] An error occurred during orchestration: {ex.Message}");
                //throw;
            }
        }
        private void LogOperationResults(ConcurrentBag<ProductOperationResult> operationResults, string baseUrl)
        {
            var failedResults = operationResults.Where(r => r.Status != "Success").ToList();
            var successfulResults = operationResults.Where(r => r.Status == "Success").ToList();

            _logger.LogInformation($"[{baseUrl}] Successful Operations:");
            foreach (var result in successfulResults)
            {
                _logger.LogInformation($"[{baseUrl}] SKU: {result.SKU}, Action: {result.ActionType}, Status: {result.Status}");
            }

            if (failedResults.Any())
            {
                _logger.LogError($"[{baseUrl}] Failed Operations:");
                foreach (var result in failedResults)
                {
                    _logger.LogError($"[{baseUrl}] SKU: {result.SKU}, Action: {result.ActionType}, Status: {result.Status}");
                }
            }
        }

        #region SimpleProducts
        private async Task ProcessSimpleProducts(List<ExcelProduct> simpleProducts, Dictionary<string, Product> existingSimpleProducts, List<ProductCategory> existingCategories, ConcurrentBag<ProductOperationResult> results)
        {
            var tasks = simpleProducts.Select(async excelProduct =>
            {
                var result = new ProductOperationResult { SKU = excelProduct.SKU };
                try
                {
                    var existingProduct = existingSimpleProducts.FirstOrDefault(x => x.Value.Sku == excelProduct.SKU).Value;

                    if (existingProduct != null)
                    {
                        if (NeedsUpdate(existingProduct, excelProduct))
                        {
                            var updatedProduct = await MapExcelToProduct(excelProduct, existingProduct, existingCategories).ConfigureAwait(false);
                            await SafeApiCall(async () => await _restApiService.UpdateProductAsync(_restApiSettings,existingProduct.Id.ToString(), updatedProduct).ConfigureAwait(false), excelProduct.SKU);

                            _logger.LogInformation($"Updated simple product: {excelProduct.SKU}");
                            result.ActionType = "Update";
                            result.Status = "Success";
                        }
                        else
                        {
                            _logger.LogInformation($"No updates needed for simple product: {excelProduct.SKU}");
                            result.ActionType = "NoUpdate";
                            result.Status = "Success";
                        }
                        existingSimpleProducts.Remove(excelProduct.SKU);
                    }
                    else
                    {
                        var newProduct = await MapExcelProductToNewProductAsync(excelProduct, existingCategories).ConfigureAwait(false);
                        await SafeApiCall(async () => await _restApiService.PostProductAsync(_restApiSettings, newProduct).ConfigureAwait(false), excelProduct.SKU);

                        _logger.LogInformation($"Created new simple product: {excelProduct.SKU}");
                        result.ActionType = "Create";
                        result.Status = "Success";
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Error processing simple product with SKU {excelProduct.SKU}: {ex.Message}");
                    result.Status = "Failed" + ex.Message;
                }

                results.Add(result);
            });

            await Task.WhenAll(tasks);
        }
 
         private bool NeedsUpdate(Product existingProduct, ExcelProduct excelProduct)
        {
            var excelCategories = new List<string>
                                {
                                    excelProduct.MajorCategory?.Trim().ToLower(),
                                    excelProduct.MinorCategory?.Trim().ToLower()
                                }.Where(c => !string.IsNullOrEmpty(c)).ToList();

            var existingCategories = existingProduct.Categories
                .Select(c => c.Name.Trim().ToLower())
                .ToList();

            // Normalize spaces and handle HTML entities for better comparison
            var normalizedExistingCategories = existingCategories
                .Select(c => NormalizeString(c))
                .Select(c => DecodeHtmlEntities(c))
                .OrderBy(c => c)
                .ToList();

            var normalizedExcelCategories = excelCategories
                .Select(c => NormalizeString(c))
                .Select(c => DecodeHtmlEntities(c))
                .OrderBy(c => c)
                .ToList();

            bool categoriesAreDifferent = !normalizedExistingCategories.SequenceEqual(normalizedExcelCategories);



            var existingImages = existingProduct.Images
                            .Select(i => NormalizeImageName(Path.GetFileName(i.Src)))
                            .Where(i => !string.IsNullOrWhiteSpace(i))
                            .OrderBy(i => i)
                            .ToList();

            var excelImages = excelProduct.Images?
                .Split(',')
                .Select(img => NormalizeImageName(img.Trim()))
                .Where(img => !string.IsNullOrWhiteSpace(img))
                .OrderBy(img => img)
                .ToList() ?? new List<string>();

            bool imagesAreDifferent = existingImages.Count > 0 || excelImages.Count > 0
               ? !existingImages.SequenceEqual(excelImages)
               : false;



            bool attributesAreDifferent = existingProduct.Attributes.Any(attr =>
               (attr.Name == "Manufacturer" && !attr.Options.Contains(excelProduct.Manufacturer)) ||
               (attr.Name == "UNSPSC" && !attr.Options.Contains(excelProduct.UNSPSC)) ||
               (attr.Name == "Product Specification Sheet" && !attr.Options.Contains(_restApiSettings.ProductSheet + excelProduct.ProductSpecificationSheet)) ||
               (attr.Name == "IsRetailItem" && !attr.Options.Contains(excelProduct.IsRetail.ToString().ToLower())));

            //bool stockQuantitiesAreEqual = NormalizeStockQuantity(existingProduct.StockQuantity) == NormalizeStockQuantity(Convert.ToInt32(excelProduct.Stock));
            bool descriptionsAreEqual = NormalizeDescription(existingProduct.Description) == NormalizeDescription(excelProduct.Description);
            var increasePrice = IncreasePriceByPercentage(excelProduct.RegularPrice);
            return
               existingProduct.Name != excelProduct.Name ||
               existingProduct.Sku != excelProduct.SKU ||
               descriptionsAreEqual ||
               //existingProduct.StockStatus != excelProduct.InStock ||
               //stockQuantitiesAreEqual ||
               existingProduct.RegularPrice != increasePrice ||
               categoriesAreDifferent ||
               attributesAreDifferent ||
               imagesAreDifferent;
        }
        private async Task<Product> MapExcelToProduct(ExcelProduct excelProduct, Product existingProduct, List<ProductCategory> existingCategories)
        {
            var product = existingProduct ?? new Product();

            if (product.Name != excelProduct.Name?.Trim())
                product.Name = excelProduct.Name?.Trim();

            product.ManageStock = false;
            if (product.Sku != excelProduct.SKU?.Trim())
                product.Sku = excelProduct.SKU?.Trim();

            product.DateModified = DateTime.Now;
            product.DateCreated = DateTime.Now;

            string regularPriceString = IncreasePriceByPercentage(excelProduct.RegularPrice?.ToString().Trim());

            if (product.RegularPrice != regularPriceString)
                product.RegularPrice = regularPriceString;

            if (product.Price != regularPriceString)
                product.Price = regularPriceString;

            product.Description = excelProduct.Description?.Trim() ?? "";
            if (!string.IsNullOrWhiteSpace(excelProduct.ProductSpecificationSheet))
            {
                string specSheetUrl = $"{_restApiSettings.ProductSheet}{excelProduct.ProductSpecificationSheet.Trim()}";
                product.Description += $"<br /><a href='{specSheetUrl}' target='_blank' rel='noopener noreferrer'>Product Specification Sheet</a>";
            }

            //int? newStockQuantity = string.IsNullOrWhiteSpace(excelProduct.Stock?.ToString())
            //    ? (int?)null
            //    : Convert.ToInt32(excelProduct.Stock);
            //if (product.StockQuantity != newStockQuantity)
            //    product.StockQuantity = newStockQuantity;
            product.StockStatus = "instock";
            //if (product.StockStatus != excelProduct.InStock?.ToString().ToLower())
            //    product.StockStatus = excelProduct.InStock?.ToString().ToLower();

            product.Status = "publish";
            // Update Categories like Variation
            product.Categories = new List<ProductCategory>();
            if (!string.IsNullOrWhiteSpace(excelProduct.MajorCategory))
            {
                var majorCategorySlug = CreateCategorySlug(excelProduct.MajorCategory);
                var majorCategoryId = GetCategoryIdBySlug(majorCategorySlug, existingCategories);

                product.Categories.Add(new ProductCategory
                {
                    Id = majorCategoryId,
                    Name = excelProduct.MajorCategory,
                    Slug = majorCategorySlug
                });
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.MinorCategory))
            {
                var minorCategorySlug = CreateCategorySlug(excelProduct.MinorCategory);
                var minorCategoryId = GetCategoryIdBySlug(minorCategorySlug, existingCategories);

                product.Categories.Add(new ProductCategory
                {
                    Id = minorCategoryId,
                    Name = excelProduct.MinorCategory,
                    Slug = minorCategorySlug
                });
            }

            // Handle Images
            if (!string.IsNullOrWhiteSpace(excelProduct.Images))
            {
                var excelImages = excelProduct.Images
                    .Split(',')
                    .Select(image => new ProductImage
                    {
                        Src = _restApiSettings.ImagesUrl + image.Trim(),
                        Name = Path.GetFileNameWithoutExtension(image.Trim()),
                        Alt = Path.GetFileNameWithoutExtension(image.Trim())
                    })
                    .ToList();

                var existingImages = existingProduct.Images.Select(img => NormalizeImageName(img.Src)).ToList();
                var newImages = new List<ProductImage>();

                foreach (var image in excelImages)
                {
                    if (!existingImages.Any(imgUrl => Path.GetFileNameWithoutExtension(imgUrl).Equals(image.Name, StringComparison.OrdinalIgnoreCase)))
                    {
                        MediaItem existingImageUrl = await _restApiService.GetExistingImageUrl(_restApiSettings, image.Name);

                        if (existingImageUrl != null)
                        {
                            newImages.Add(new ProductImage
                            {
                                Id = existingImageUrl.Id,
                                DateCreated = existingImageUrl.Date,
                                DateCreatedGmt = existingImageUrl.DateGmt,
                                DateModified = existingImageUrl.Modified,
                                DateModifiedGmt = existingImageUrl.ModifiedGmt,
                                Src = existingImageUrl.Title.Rendered,
                                Name = existingImageUrl.Alt,
                                Alt = existingImageUrl.Alt
                            });
                        }
                        else
                        {
                            newImages.Add(image);
                            _logger.LogWarning($"Image {image.Name} not found on the product or WooCommerce server. Using the provided image.");
                        }
                    }
                }

                if (newImages.Any())
                {
                    foreach (ProductImage image in newImages)
                    {
                        product.Images.Add(image);

                    }
                }
                else
                {
                    _logger.LogInformation($"Images for product {excelProduct.SKU} are already up-to-date.");
                }
            }

            var newAttributes = new List<ProductAttribute>
                            {
                                UpdateAttribute(existingProduct.Attributes, "Manufacturer", "pa_manufacturer", excelProduct.Manufacturer?.Trim(), 1),
                                UpdateAttribute(existingProduct.Attributes, "UNSPSC", "pa_unspsc", excelProduct.UNSPSC?.Trim(), 2),
                                UpdateAttribute(
                                    existingProduct.Attributes,
                                    "Product Specification Sheet",
                                    "pa_product-specification-sheet",
                                    !string.IsNullOrWhiteSpace(excelProduct.ProductSpecificationSheet)
                                        ? $"<a href='{_restApiSettings.ProductSheet}{excelProduct.ProductSpecificationSheet.Trim()}' target='_blank' rel='noopener noreferrer'>{_restApiSettings.ProductSheet}{excelProduct.ProductSpecificationSheet.Trim()}</a>"
                                        : "",
                                    3),
                                UpdateAttribute(existingProduct.Attributes, "IsRetailItem", "pa_isretailitem", excelProduct.IsRetail.ToString().ToLower(), 4)
                            };
            if (!product.Attributes.SequenceEqual(newAttributes, new ProductAttributeComparer()))
            {
                product.Attributes = newAttributes;
            }

            return product;
        }

        private async Task<Product> MapExcelProductToNewProductAsync(ExcelProduct excelProduct, List<ProductCategory> existingCategories)
        {
            var newProduct = new Product();

            newProduct.Name = excelProduct.Name?.Trim();
            newProduct.Sku = excelProduct.SKU?.Trim();
            newProduct.ManageStock = false;
            string regularPriceString = IncreasePriceByPercentage(excelProduct.RegularPrice?.ToString().Trim());
            newProduct.RegularPrice = regularPriceString;
            newProduct.Price = regularPriceString;
            newProduct.DateCreated = DateTime.Now;

            newProduct.Description = excelProduct.Description?.Trim() ?? "";
            if (!string.IsNullOrWhiteSpace(excelProduct.ProductSpecificationSheet))
            {
                string specSheetUrl = $"{_restApiSettings.ProductSheet}{excelProduct.ProductSpecificationSheet.Trim()}";
                newProduct.Description += $"<br /><a href='{specSheetUrl}' target='_blank' rel='noopener noreferrer'>Product Specification Sheet</a>";
            }
            //int? stockQuantity = string.IsNullOrWhiteSpace(excelProduct.Stock?.ToString())
            //    ? (int?)null
            //    : Convert.ToInt32(excelProduct.Stock);
            //newProduct.StockQuantity = stockQuantity;

            newProduct.Status = "publish";

            //newProduct.StockStatus = excelProduct.InStock?.ToString().ToLower();
            newProduct.StockStatus = "instock";

            // Update Categories like Variation
            newProduct.Categories = new List<ProductCategory>();
            if (!string.IsNullOrWhiteSpace(excelProduct.MajorCategory))
            {
                var majorCategorySlug = CreateCategorySlug(excelProduct.MajorCategory);
                var majorCategoryId = GetCategoryIdBySlug(majorCategorySlug, existingCategories);

                newProduct.Categories.Add(new ProductCategory
                {
                    Id = majorCategoryId,
                    Name = excelProduct.MajorCategory,
                    Slug = majorCategorySlug
                });
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.MinorCategory))
            {
                var minorCategorySlug = CreateCategorySlug(excelProduct.MinorCategory);
                var minorCategoryId = GetCategoryIdBySlug(minorCategorySlug, existingCategories);

                newProduct.Categories.Add(new ProductCategory
                {
                    Id = minorCategoryId,
                    Name = excelProduct.MinorCategory,
                    Slug = minorCategorySlug
                });
            }
            // Directly add images from the provided URLs
            // Check for existing images on the WooCommerce server
            if (!string.IsNullOrWhiteSpace(excelProduct.Images))
            {
                var excelImages = excelProduct.Images
                    .Split(',')
                    .Select(image => new ProductImage
                    {
                        Src = _restApiSettings.ImagesUrl + image.Trim(),
                        Name = Path.GetFileNameWithoutExtension(image.Trim()),
                        Alt = Path.GetFileNameWithoutExtension(image.Trim())
                    })
                    .ToList();

                var newProductImages = new List<ProductImage>();

                foreach (var image in excelImages)
                {
                    // Check if the image already exists on the WooCommerce server
                    MediaItem existingImageUrl = await _restApiService.GetExistingImageUrl(_restApiSettings,image.Name);

                    if (existingImageUrl != null)
                    {
                        // Add the existing image to newProductImages (to preserve its metadata)
                        newProductImages.Add(new ProductImage
                        {

                            Id = existingImageUrl.Id,
                            DateCreated = existingImageUrl.Date,
                            DateCreatedGmt = existingImageUrl.DateGmt,
                            DateModified = existingImageUrl.Modified,
                            DateModifiedGmt = existingImageUrl.ModifiedGmt,
                            Src = existingImageUrl.GuIdLink.Rendered, // Correct URL of the image
                            Name = existingImageUrl.Alt,
                            Alt = existingImageUrl.Alt
                        });
                    }
                    else
                    {
                        newProductImages.Add(new ProductImage
                        {
                            // Don't include Id since the image is new and doesn't have one
                            DateCreated = null,
                            DateCreatedGmt = null,
                            DateModified = null,
                            DateModifiedGmt = null,
                            Src = image.Src, // Use the image source from the Excel file
                            Name = image.Name,
                            Alt = image.Alt
                        });
                        _logger.LogWarning($"Image {image.Name} not found on the server. Creating new image.");
                    }
                }

                // Ensure the Images collection is initialized
                if (newProduct.Images == null)
                {
                    newProduct.Images = new List<ProductImage>();
                }

                // Add new images to the product
                if (newProductImages.Any())
                {
                    foreach (ProductImage image in newProductImages)
                    {
                        newProduct.Images.Add(image);
                    }
                }
            }



            newProduct.Attributes = new List<ProductAttribute>
                        {
                            new ProductAttribute
                            {
                                Id = 1,
                                Name = "Manufacturer",
                                Slug = "pa_manufacturer",
                                Position ="1",
                                Visible = "true",
                                Variation="false",
                                Options = new List<string> { excelProduct.Manufacturer?.Trim() }
                            },
                            new ProductAttribute
                            {
                                Id = 2,
                                Name = "UNSPSC",
                                Slug = "pa_unspsc",
                                Position ="2",
                                Visible = "true",
                                Variation="false",
                                Options = new List<string> { excelProduct.UNSPSC?.Trim() }
                            },
                             new ProductAttribute
                            {
                                Id = 3,
                                Name = "Product Specification Sheet",
                                Slug = "pa_product-specification-sheet",
                                Position ="3",
                                Visible = "true",
                                Variation="false",
                                Options = new List<string>
                                {
                                    !string.IsNullOrWhiteSpace(excelProduct.ProductSpecificationSheet)
                                    ? $"<a href='{_restApiSettings.ProductSheet}{excelProduct.ProductSpecificationSheet.Trim()}' target='_blank' rel='noopener noreferrer'>{_restApiSettings.ProductSheet}{excelProduct.ProductSpecificationSheet.Trim()}</a>"
                                    : ""
                                }
                            },
                            new ProductAttribute
                            {
                                Id = 4,
                                Name = "IsRetailItem",
                                Slug = "pa_isretailitem",
                                Position ="4",
                                Visible = "true",
                                Variation="false",
                                Options = new List<string> { excelProduct.IsRetail.ToString().ToLower() }
                            }
                        };
            return newProduct;
        }

        #endregion


        #region VariableProducts
        private async Task ProcessVariableProducts(List<ExcelProduct> variableProducts, Dictionary<string, ProductWithVariations> existingVariableProducts, List<ProductCategory> existingCategories, ConcurrentBag<ProductOperationResult> results)
        {
            var tasks = variableProducts.Select(async parentProduct =>
            {
                var parentSku = parentProduct.SKU;
                var result = new ProductOperationResult { SKU = parentSku };

                try
                {
                    if (existingVariableProducts.TryGetValue(parentSku, out var existingParentProduct))

                    {
                        if (NeedsParentProductUpdate(existingParentProduct.Product, parentProduct, existingParentProduct.Variations))
                        {
                            var updatedParentProduct = await UpdateMapParentExcelToProductAsync(parentProduct, existingParentProduct.Product, existingCategories);
                            await _restApiService.UpdateProductAsync(_restApiSettings, existingParentProduct.Product.Id.ToString(), updatedParentProduct);

                            _logger.LogInformation($"Updated variable parent product: {parentSku}");
                            result.ActionType = "Update";
                            result.Status = "Success";
                        }

                        var parentProductId = existingParentProduct.Product.Id.ToString();
                        var existingVariations = existingParentProduct.Variations;

                        foreach (var excelVariation in parentProduct.Variations)
                        {
                            await ProcessVariationAsync(parentProductId, excelVariation, existingVariations);
                        }
                    }
                    else
                    {
                        var newParentProduct = await MapExcelParentToNewVariableProductAsync(parentProduct, existingCategories);
                        var createdParentProduct = await SafeApiCall(async () => await _restApiService.PostProductAsync(_restApiSettings, newParentProduct), parentSku);

                        foreach (var excelVariation in parentProduct.Variations)
                        {
                            await ProcessVariationAsync(createdParentProduct.Id.ToString(), excelVariation, null);
                        }

                        _logger.LogInformation($"Created new variable parent product: {parentSku}");
                        result.ActionType = "Create";
                        result.Status = "Success";
                    }

                    existingVariableProducts.Remove(parentSku);
                }
                catch (Exception ex)
                {
                    _logger.LogError($"An unexpected error occurred while processing variable product with SKU {parentSku}: {ex.Message}", ex);
                    result.Status = "Failed" + ex.Message;
                }

                results.Add(result); // Store the result
            });

            await Task.WhenAll(tasks);
        }

        private async Task ProcessVariationAsync(string parentProductId, ExcelProduct excelVariation, List<ProductVariation> existingVariations)
        {
            var existingVariation = existingVariations?.FirstOrDefault(v => v.sku == excelVariation.SKU);

            if (existingVariation != null)
            {
                if (NeedsVariationUpdate(existingVariation, excelVariation))
                {
                    var updatedVariation = UpdaateMapVariationExcelToVariation(excelVariation, existingVariation);
                    var jsonPrd = JsonConvert.SerializeObject(updatedVariation, Formatting.Indented);

                    await _restApiService.UpdateProductVariationAsync(_restApiSettings, parentProductId, existingVariation.id.ToString(), updatedVariation);
                    _logger.LogInformation($"Updated variation: {excelVariation.SKU} for parent product: {parentProductId}");
                }
                else
                {
                    _logger.LogInformation($"No updates needed for variation: {excelVariation.SKU}");
                }
            }
            else
            {
                var newVariation = MapExcelProductToNewVariation(excelVariation);
                var jsonPrd3 = JsonConvert.SerializeObject(newVariation, Formatting.Indented);

                await _restApiService.PostProductVariationAsync(_restApiSettings, parentProductId, newVariation);
                _logger.LogInformation($"Created new variation: {excelVariation.SKU} for parent product: {parentProductId}");
            }
        }

        private bool NeedsVariationUpdate(ProductVariation existingVariation, ExcelProduct excelProduct)
        {
            bool nameIsDifferent = existingVariation.name != excelProduct.Name?.Trim();
            bool descriptionIsDifferent = existingVariation.description != excelProduct.Description?.Trim();

            //bool manageStockIsDifferent = existingVariation.manageStock != (excelProduct.ManageStock?.ToLower() == "yes");
            //bool stockStatusIsDifferent = existingVariation.stockStatus?.ToLower() != excelProduct.InStock?.ToLower();
            //bool stockQuantityIsDifferent = existingVariation.stockQuantity != Convert.ToInt32(excelProduct.Stock);

            var regularPrice = IncreasePriceByPercentage(excelProduct.RegularPrice);
            bool regularPriceIsDifferent = existingVariation.regularPrice != regularPrice;
            bool priceIsDifferent = existingVariation.price != regularPrice;


            var existingUomAttribute = existingVariation.attributes.FirstOrDefault(a => a.name == "Units of Measurement");
            bool unitsOfMeasurementIsDifferent = existingUomAttribute?.option != excelProduct.UnitsOfMeasurement?.Trim();

            return nameIsDifferent || descriptionIsDifferent ||
                  //manageStockIsDifferent || stockStatusIsDifferent || stockQuantityIsDifferent ||
                  regularPriceIsDifferent || unitsOfMeasurementIsDifferent;
        }

        private bool NeedsParentProductUpdate(Product existingProduct, ExcelProduct excelProduct, List<ProductVariation> existingVariations)
        {
            bool nameIsDifferent = existingProduct.Name != excelProduct.Name?.Trim();
            bool descriptionIsDifferent = existingProduct.Description != excelProduct.Description?.Trim();

            bool categoriesAreDifferent = !existingProduct.Categories
               .Select(c => c.Slug)
               .OrderBy(s => s)
               .SequenceEqual(new List<string> { excelProduct.MajorCategory, excelProduct.MinorCategory }
                   .Select(c => CreateSlug(c))
                   .OrderBy(s => s)
               );


            bool manufacturerIsDifferent = existingProduct.Attributes.FirstOrDefault(a => a.Name == "Manufacturer")?.Options.FirstOrDefault() != excelProduct.Manufacturer?.Trim();
            bool unspscIsDifferent = existingProduct.Attributes.FirstOrDefault(a => a.Name == "UNSPSC")?.Options.FirstOrDefault() != excelProduct.UNSPSC?.Trim();
            bool specificationSheetIsDifferent = existingProduct.Attributes.FirstOrDefault(a => a.Name == "Product Specification Sheet")?.Options.FirstOrDefault() != _restApiSettings.ProductSheet + excelProduct.ProductSpecificationSheet?.Trim();
            bool applicationIsDifferent = existingProduct.Attributes.FirstOrDefault(a => a.Name == "Application")?.Options.FirstOrDefault() != excelProduct.Application?.Trim();
            bool supplierIdIsDifferent = existingProduct.Attributes.FirstOrDefault(a => a.Name == "Supplier ID")?.Options.FirstOrDefault() != excelProduct.SupplierID?.Trim();
            bool isRetailIsDifferent = existingProduct.Attributes.FirstOrDefault(a => a.Name == "IsRetail")?.Options.FirstOrDefault()?.ToLower() != excelProduct.IsRetail?.ToLower();
            bool usageIsDifferent = existingProduct.Attributes.FirstOrDefault(a => a.Name == "Usage")?.Options.FirstOrDefault() != excelProduct.Usage?.Trim();

            bool variationsNeedUpdate = existingVariations.Any(variation =>
            {
                var correspondingExcelVariation = excelProduct.Variations?.FirstOrDefault(v => v.SKU == variation.sku);
                return correspondingExcelVariation != null && NeedsVariationUpdate(variation, correspondingExcelVariation);
            });

            return nameIsDifferent || descriptionIsDifferent || categoriesAreDifferent ||
                  manufacturerIsDifferent || unspscIsDifferent || specificationSheetIsDifferent ||
                  applicationIsDifferent || supplierIdIsDifferent || isRetailIsDifferent || usageIsDifferent ||
                  variationsNeedUpdate;
        }

        private async Task<Product> UpdateMapParentExcelToProductAsync(ExcelProduct excelProduct, Product existingProduct, List<ProductCategory> existingCategories)
        {
            var product = existingProduct ?? new Product();
            var regularPrice = IncreasePriceByPercentage(excelProduct.RegularPrice);
            product.Name = excelProduct.Name?.Trim();
            product.RegularPrice = regularPrice;
            product.Price = regularPrice;
            product.DateModified = DateTime.Now;
            product.DateCreated = DateTime.Now;

            product.Description = excelProduct.Description?.Trim();
            product.Slug = CreateSlug(product.Name);
            product.Status = "publish";
            product.Categories = new List<ProductCategory>();
            if (!string.IsNullOrWhiteSpace(excelProduct.MajorCategory))
            {
                var majorCategorySlug = CreateSlug(excelProduct.MajorCategory);
                var majorCategoryId = GetCategoryIdBySlug(majorCategorySlug, existingCategories);

                product.Categories.Add(new ProductCategory
                {
                    Id = majorCategoryId,
                    Name = excelProduct.MajorCategory,
                    Slug = majorCategorySlug
                });
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.MinorCategory))
            {
                var minorCategorySlug = CreateSlug(excelProduct.MinorCategory);
                var minorCategoryId = GetCategoryIdBySlug(minorCategorySlug, existingCategories);

                product.Categories.Add(new ProductCategory
                {
                    Id = minorCategoryId,
                    Name = excelProduct.MinorCategory,
                    Slug = minorCategorySlug
                });
            }

            // Handle images 
            if (!string.IsNullOrWhiteSpace(excelProduct.Images))
            {
                var excelImages = excelProduct.Images.Split(',').Select(img => new ProductImage
                {
                    Src = _restApiSettings.ImagesUrl + img.Trim(),
                    Name = Path.GetFileNameWithoutExtension(img.Trim()),
                    Alt = Path.GetFileNameWithoutExtension(img.Trim())
                }).ToList();

                // Get existing product image URLs for comparison
                var existingImages = existingProduct.Images.Select(img => NormalizeImageName(img.Src)).ToList();

                var newImages = new List<ProductImage>();

                foreach (var image in excelImages)
                {
                    if (!existingImages.Any(imgUrl => Path.GetFileNameWithoutExtension(imgUrl).Equals(image.Name, StringComparison.OrdinalIgnoreCase)))
                    {
                        MediaItem existingImageUrl = await _restApiService.GetExistingImageUrl(_restApiSettings, image.Name);

                        if (existingImageUrl != null)
                        {
                            newImages.Add(new ProductImage
                            {
                                Id = existingImageUrl.Id,
                                DateCreated = existingImageUrl.Date,
                                DateCreatedGmt = existingImageUrl.DateGmt,
                                DateModified = existingImageUrl.Modified,
                                DateModifiedGmt = existingImageUrl.ModifiedGmt,
                                Src = existingImageUrl.Title.Rendered,
                                Name = existingImageUrl.Alt,
                                Alt = existingImageUrl.Alt
                            });
                        }
                        else
                        {
                            newImages.Add(image);
                            _logger.LogWarning($"Image {image.Name} not found on the product or WooCommerce server. Using the provided image.");
                        }
                    }
                }

                if (newImages.Any())
                {
                    foreach (ProductImage image in newImages)
                    {
                        product.Images.Add(image);

                    }
                }
                else
                {
                    _logger.LogInformation($"Images for product {excelProduct.SKU} are already up-to-date.");
                }
            }
            else
            {
                // If no images are provided in the Excel file, log and don't send updates for images
                _logger.LogInformation($"No images provided for product {excelProduct.SKU}. Existing images will remain unchanged.");
            }
            var attributes = new List<ProductAttribute>();

            if (!string.IsNullOrWhiteSpace(excelProduct.Manufacturer))
            {
                attributes.Add(new ProductAttribute
                {
                    Id = 1,
                    Name = "Manufacturer",
                    Slug = CreateSlug("Manufacturer"),
                    Position = "0",
                    Visible = "true",
                    Variation = "false",
                    Options = new List<string> { excelProduct.Manufacturer }
                });
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.UNSPSC))
            {
                attributes.Add(new ProductAttribute
                {
                    Id = 2,
                    Name = "UNSPSC",
                    Slug = CreateSlug("UNSPSC"),
                    Position = "1",
                    Visible = "true",
                    Variation = "false",
                    Options = new List<string> { excelProduct.UNSPSC }
                });
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.ProductSpecificationSheet))
            {
                string specSheetUrl = _restApiSettings.ProductSheet + excelProduct.ProductSpecificationSheet.Trim();

                product.Description += $"<br /><a href='{specSheetUrl}' target='_blank' rel='noopener noreferrer'>Product Specification Sheet</a>";

                attributes.Add(new ProductAttribute
                {
                    Id = 3,
                    Name = "Product Specification Sheet",
                    Slug = CreateSlug("Product Specification Sheet"),
                    Position = "2",
                    Visible = "true",
                    Variation = "false",
                    Options = new List<string> { specSheetUrl }
                });
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.IsRetail))
            {
                attributes.Add(new ProductAttribute
                {
                    Id = 4,
                    Name = "IsRetailItem",
                    Slug = CreateSlug("IsRetailItem"),
                    Position = "3",
                    Visible = "true",
                    Variation = "false",
                    Options = new List<string> { excelProduct.IsRetail.ToLower() }
                });
            }

            var unitsOfMeasurementOptions = GetUnitsOfMeasurementOptions(excelProduct.Variations);

            if (unitsOfMeasurementOptions.Any())
            {
                attributes.Add(new ProductAttribute
                {
                    Id = 5,
                    Name = "Units of Measurement",
                    Slug = CreateSlug("Units of Measurement"),
                    Position = "4",
                    Visible = "true",
                    Variation = "true",
                    Options = unitsOfMeasurementOptions
                });
            }

            product.Attributes = attributes;

            //product.ManageStock = excelProduct.ManageStock?.ToLower() == "yes";
            product.ManageStock = false;
            product.StockStatus = "instock";
            // Conditionally set stock properties only if they have valid values
            //if (!string.IsNullOrWhiteSpace(excelProduct.InStock))
            //{
            //    product.StockQuantity = Convert.ToInt32(excelProduct.Stock);
            //}

            //if (!string.IsNullOrWhiteSpace(excelProduct.InStock))
            //{
            //    product.StockStatus = excelProduct.InStock.ToLower();
            //}

            return product;
        }

        private ProductVariation UpdaateMapVariationExcelToVariation(ExcelProduct excelProduct, ProductVariation existingVariation)
        {
            var variation = existingVariation ?? new ProductVariation();
            var increasedPrice = IncreasePriceByPercentage(excelProduct.RegularPrice);
            // Map basic properties from ExcelProduct
            variation.sku = excelProduct.SKU?.Trim();
            variation.name = excelProduct.UnitsOfMeasurement?.Trim();
            variation.regularPrice = increasedPrice;
            variation.price = increasedPrice;
            variation.description = excelProduct.Description?.Trim();

            variation.name = excelProduct.UnitsOfMeasurement ?? excelProduct.SKU;

            //variation.stockQuantity = excelProduct.Stock != null
            //   ? Convert.ToInt32(excelProduct.Stock)
            //   : (int?)null;

            //variation.manageStock = string.Equals(excelProduct.ManageStock, "yes", StringComparison.OrdinalIgnoreCase);
            variation.manageStock = false;
            variation.stockStatus = "instock";
            //variation.stockStatus = string.Equals(excelProduct.InStock, "instock", StringComparison.OrdinalIgnoreCase)
            //    ? "instock"
            //    : "outofstock";

            variation.parentId = excelProduct.Parent != null ? Convert.ToInt32(excelProduct.Parent) : 0;


            variation.attributes = new List<ProductVariation.ProductAttribute>();

            if (!string.IsNullOrWhiteSpace(excelProduct.UnitsOfMeasurement))
            {
                variation.attributes.Add(new ProductVariation.ProductAttribute
                {
                    id = 5,
                    name = "Units of Measurement",
                    option = excelProduct.UnitsOfMeasurement
                });
            }

            variation.metaData = new List<ProductVariation.ProductMetaData>
                                {
                                    new ProductVariation.ProductMetaData
                                    {
                                        id = existingVariation?.metaData?.FirstOrDefault()?.id ?? 0,
                                        key = "_wp_page_template",
                                        value = "default"
                                    }
                                };

            return variation;
        }

        private async Task<Product> MapExcelParentToNewVariableProductAsync(ExcelProduct excelProduct, List<ProductCategory> existingCategories)
        {
            var increasedPrice = IncreasePriceByPercentage(excelProduct.RegularPrice);
            var newProduct = new Product
            {
                Name = excelProduct.Name?.Trim() ?? "Unnamed Product",
                Sku = excelProduct.SKU?.Trim() ?? Guid.NewGuid().ToString(),
                Type = "variable",
                RegularPrice = increasedPrice ?? "0.00",
                Price = increasedPrice ?? "0.00",
                Description = excelProduct.Description?.Trim() ?? "No description available",
                StockStatus = "instock",
                ManageStock = false
                //StockStatus = !string.IsNullOrWhiteSpace(excelProduct.InStock)
                //                ? excelProduct.InStock.ToLower()
                //                : "instock",
                //ManageStock = excelProduct.ManageStock?.ToLower() == "yes"
            };
            newProduct.DateModified = DateTime.Now;
            newProduct.DateCreated = DateTime.Now;
            newProduct.Status = "publish";

            var majorCategory = await GetOrCreateCategoryAsync(excelProduct.MajorCategory?.Trim(), existingCategories);
            var minorCategory = await GetOrCreateCategoryAsync(excelProduct.MinorCategory?.Trim(), existingCategories);
            newProduct.Categories = new List<ProductCategory> { majorCategory, minorCategory }.Where(c => c != null).ToList();

            // Directly add images without checking the media library
            // Check if images exist on the WooCommerce server before creating new ones
            // Check if images exist on the WooCommerce server before creating new ones
            if (!string.IsNullOrWhiteSpace(excelProduct.Images))
            {
                var excelImages = excelProduct.Images
                    .Split(',')
                    .Select(image => new ProductImage
                    {
                        Src = _restApiSettings.ImagesUrl + image.Trim(),
                        Name = Path.GetFileNameWithoutExtension(image.Trim()),
                        Alt = Path.GetFileNameWithoutExtension(image.Trim())
                    })
                    .ToList();

                var newProductImages = new List<ProductImage>();

                foreach (var image in excelImages)
                {
                    // Check if the image already exists on the WooCommerce server
                    MediaItem existingImageUrl = await _restApiService.GetExistingImageUrl(_restApiSettings, image.Name);

                    if (existingImageUrl != null)
                    {
                        // Use the existing image if found
                        newProductImages.Add(new ProductImage
                        {
                            Id = existingImageUrl.Id,
                            DateCreated = existingImageUrl.Date,
                            DateCreatedGmt = existingImageUrl.DateGmt,
                            DateModified = existingImageUrl.Modified,
                            DateModifiedGmt = existingImageUrl.ModifiedGmt,
                            Src = existingImageUrl.GuIdLink.Rendered,
                            Name = existingImageUrl.Alt,
                            Alt = existingImageUrl.Alt
                        });
                    }
                    else
                    {
                        // If the image is not found on the server, use the one provided in the Excel file
                        newProductImages.Add(new ProductImage
                        {
                            // Omit the Id since it's a new image
                            DateCreated = null,
                            DateCreatedGmt = null,
                            DateModified = null,
                            DateModifiedGmt = null,
                            Src = image.Src,
                            Name = image.Name,
                            Alt = image.Alt
                        });
                        _logger.LogWarning($"Image {image.Name} not found on WooCommerce server. Using the provided URL.");
                    }
                }

                // Ensure the Images collection is initialized
                if (newProduct.Images == null)
                {
                    newProduct.Images = new List<ProductImage>();
                }

                // Add new images to the product
                if (newProductImages.Any())
                {
                    newProduct.Images = newProductImages;
                }
            }
            //// Handle images with GetExistingImageUrl
            //if (!string.IsNullOrWhiteSpace(excelProduct.Images))
            //{
            //    var excelImages = excelProduct.Images
            //        .Split(',')
            //        .Select(image => new ProductImage
            //        {
            //            Src = _restApiSettings.ImagesUrl + image.Trim(),
            //            Name = Path.GetFileNameWithoutExtension(image.Trim()),
            //            Alt = Path.GetFileNameWithoutExtension(image.Trim())
            //        })
            //        .ToList();

            //    var newProductImages = new List<ProductImage>();

            //    foreach (var image in excelImages)
            //    {
            //        // Check if the image already exists in the media library
            //        var existingImageUrl = await _restApiService.GetExistingImageUrl(image.Name);

            //        if (!string.IsNullOrEmpty(existingImageUrl))
            //        {
            //            // Use the existing image URL if found in the media library
            //            newProductImages.Add(new ProductImage
            //            {
            //                Src = existingImageUrl,
            //                Name = image.Name,
            //                Alt = image.Alt
            //            });
            //        }
            //        else
            //        {
            //            // If the image is not found in the media library, log and use the original URL
            //            _logger.LogWarning($"Image {image.Name} not found on WooCommerce for SKU {excelProduct.SKU}. Using provided URL.");

            //            // Use the original image source as it was provided from Excel
            //            newProductImages.Add(new ProductImage
            //            {
            //                Src = image.Src, // Keep the image from the Excel file
            //                Name = image.Name,
            //                Alt = image.Alt
            //            });
            //        }
            //    }

            //    if (newProductImages.Any())
            //    {
            //        newProduct.Images = newProductImages;
            //    }
            //    else
            //    {
            //        _logger.LogInformation($"No new images to update for product {excelProduct.SKU}");
            //    }
            //}

            var attributes = new List<ProductAttribute>
            {
                new ProductAttribute
                {
                    Id = 1,
                    Name = "Manufacturer",
                    Slug = "pa_manufacturer",
                    Position = "1",
                    Visible = "true",
                    Variation = "false",
                    Options = new List<string> { excelProduct.Manufacturer?.Trim() ?? "Unknown" }
                },
                new ProductAttribute
                {
                    Id = 2,
                    Name = "UNSPSC",
                    Slug = "pa_unspsc",
                    Position = "2",
                    Visible = "true",
                    Variation = "false",
                    Options = new List<string> { excelProduct.UNSPSC?.Trim() ?? "N/A" }
                }
            };

            // Add the Product Specification Sheet as both an attribute and a link in the description
            if (!string.IsNullOrWhiteSpace(excelProduct.ProductSpecificationSheet))
            {
                string specSheetUrl = _restApiSettings.ProductSheet + excelProduct.ProductSpecificationSheet.Trim();

                // Append to product description
                newProduct.Description += $"<br /><a href='{specSheetUrl}' target='_blank' rel='noopener noreferrer'>Product Specification Sheet</a>";

                // Add as product attribute
                attributes.Add(new ProductAttribute
                {
                    Id = 3,
                    Name = "Product Specification Sheet",
                    Slug = "pa_product-specification-sheet",
                    Position = "3",
                    Visible = "true",
                    Variation = "false",
                    Options = new List<string>
            {
                $"<a href='{specSheetUrl}' target='_blank' rel='noopener noreferrer'>{specSheetUrl}</a>"
            }
                });
            }

            attributes.Add(new ProductAttribute
            {
                Id = 4,
                Name = "IsRetailItem",
                Slug = "pa_isretailitem",
                Position = "4",
                Visible = "true",
                Variation = "false",
                Options = new List<string> { excelProduct.IsRetail?.ToString().ToLower() ?? "false" }
            });

            // Include Units of Measurement if available
            var unitsOfMeasurementOptions = GetUnitsOfMeasurementOptions(excelProduct.Variations);
            if (unitsOfMeasurementOptions.Any())
            {
                attributes.Add(new ProductAttribute
                {
                    Id = 5,
                    Name = "Units of Measurement",
                    Slug = "pa_units-of-measurement",
                    Position = "5",
                    Visible = "true",
                    Variation = "true",
                    Options = unitsOfMeasurementOptions
                });
            }

            newProduct.Attributes = attributes;

            return newProduct;
        }

        private ProductVariation MapExcelProductToNewVariation(ExcelProduct excelVariation)
        {
            var variation = new ProductVariation
            {
                sku = excelVariation.SKU?.Trim(),
                regularPrice = IncreasePriceByPercentage(excelVariation.RegularPrice?.Trim()),
                manageStock = false,
                stockStatus = "instock",
                //manageStock = string.Equals(excelVariation.ManageStock, "yes", StringComparison.OrdinalIgnoreCase),
                //stockQuantity = !string.IsNullOrWhiteSpace(excelVariation.Stock?.ToString()) ? Convert.ToInt32(excelVariation.Stock) : (int?)null,
                //stockStatus = string.Equals(excelVariation.InStock, "instock", StringComparison.OrdinalIgnoreCase) ? "instock" : "outofstock",
                description = excelVariation.Description?.Trim(),
            };
            variation.attributes = new List<ProductVariation.ProductAttribute>
                                    {
                                        new ProductVariation.ProductAttribute
                                        {
                                            id = 5,
                                            option = excelVariation.UnitsOfMeasurement?.Trim()
                                        }
                                    };

            return variation;
        }
 
        #endregion


        #region Helpers
        private async Task<List<ProductImage>> MapImagesAsync(ExcelProduct excelProduct, Product existingProduct)
        {
            var images = new List<ProductImage>();

            if (!string.IsNullOrWhiteSpace(excelProduct.Images))
            {
                var excelImages = excelProduct.Images.Split(',').Select(img => img.Trim()).ToList();

                foreach (var img in excelImages)
                {
                    var existingImage = await _restApiService.GetExistingImageUrl(_restApiSettings, img);
                    if (existingImage != null)
                    {
                        images.Add(new ProductImage
                        {
                            Id = existingImage.Id,
                            Src = existingImage.GuIdLink.Rendered,
                            Name = existingImage.Title.Rendered,
                            Alt = existingImage.Alt
                        });
                    }
                    else
                    {
                        images.Add(new ProductImage
                        {
                            Src = _restApiSettings.ImagesUrl + img,
                            Name = Path.GetFileNameWithoutExtension(img),
                            Alt = Path.GetFileNameWithoutExtension(img)
                        });
                    }
                }
            }

            return images;
        }

        private async Task<List<ProductCategory>> MapCategoriesAsync(ExcelProduct excelProduct, List<ProductCategory> existingCategories)
        {
            var categories = new List<ProductCategory>();

            if (!string.IsNullOrWhiteSpace(excelProduct.MajorCategory))
            {
                var majorCategory = await GetOrCreateCategoryAsync(excelProduct.MajorCategory, existingCategories);
                if (majorCategory != null)
                {
                    categories.Add(majorCategory);
                }
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.MinorCategory))
            {
                var minorCategory = await GetOrCreateCategoryAsync(excelProduct.MinorCategory, existingCategories);
                if (minorCategory != null)
                {
                    categories.Add(minorCategory);
                }
            }

            return categories;
        }

        private List<ProductAttribute> MapAttributes(ExcelProduct excelProduct)
        {
            var attributes = new List<ProductAttribute>();

            if (!string.IsNullOrWhiteSpace(excelProduct.Manufacturer))
            {
                attributes.Add(new ProductAttribute
                {
                    Name = "Manufacturer",
                    Options = new List<string> { excelProduct.Manufacturer.Trim() }
                });
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.UNSPSC))
            {
                attributes.Add(new ProductAttribute
                {
                    Name = "UNSPSC",
                    Options = new List<string> { excelProduct.UNSPSC.Trim() }
                });
            }

            if (!string.IsNullOrWhiteSpace(excelProduct.IsRetail))
            {
                attributes.Add(new ProductAttribute
                {
                    Name = "IsRetailItem",
                    Options = new List<string> { excelProduct.IsRetail.ToLower().Trim() }
                });
            }

            return attributes;
        }

        private int NormalizeStockQuantity(int? stockQuantity)
        {
            // Ensures a non-null stock quantity by returning 0 if it's null
            return stockQuantity ?? 0;
        }

        private string NormalizeDescription(string description)
        {
            // Strips HTML tags from the description and trims whitespace
            if (string.IsNullOrWhiteSpace(description)) return string.Empty;
            return System.Text.RegularExpressions.Regex.Replace(description, "<.*?>", "").Trim();
        }

        private string NormalizeString(string input)
        {
            // Removes excess whitespace, ensuring only single spaces remain
            if (string.IsNullOrWhiteSpace(input)) return input;
            return System.Text.RegularExpressions.Regex.Replace(input.Trim(), @"\s+", " ");
        }

        private string DecodeHtmlEntities(string input)
        {
            // Decodes HTML entities, e.g., &amp; to &
            if (string.IsNullOrWhiteSpace(input)) return input;
            return System.Net.WebUtility.HtmlDecode(input);
        }

        private string NormalizeImageName(string input)
        {
            // Trims and normalizes image names by reducing whitespace
            if (string.IsNullOrWhiteSpace(input)) return input?.Trim();
            return System.Text.RegularExpressions.Regex.Replace(input.Trim(), @"\s+", " ");
        }

        private string IncreasePriceByPercentage(string originalPrice)
        {
            // Increases price by a defined percentage in the settings
            if (decimal.TryParse(originalPrice, out decimal price) && _restApiSettings.PriceIncreasePercentage > 0)
            {
                decimal percentageIncrease = _restApiSettings.PriceIncreasePercentage / 100m;
                decimal increasedPrice = price + (price * percentageIncrease);

                return increasedPrice.ToString("F2");
            }
            return originalPrice;
        }

        private async Task<T> SafeApiCall<T>(Func<Task<T>> apiCall, string sku, int retryCount = 1)
        {
            // Executes an API call with retry logic if there's a specific error
            try
            {
                return await apiCall();
            }
            catch (HttpRequestException ex)
            {
                var errorMessage = ex.Message;

                if (errorMessage.Contains("product_invalid_sku") && retryCount > 0)
                {
                    var resourceIdMatch = Regex.Match(errorMessage, @"""resource_id"":(\d+)");
                    if (resourceIdMatch.Success && int.TryParse(resourceIdMatch.Groups[1].Value, out var resourceId))
                    {
                        _logger.LogInformation("Conflict detected for SKU {Sku}. Deleting existing product with ID {ResourceId}.", sku, resourceId);
                        bool response = await _restApiService.DeleteProductAsync(_restApiSettings, resourceId.ToString(), force: true);

                        if (response)
                        {
                            await Task.Delay(TimeSpan.FromSeconds(3));
                            return await SafeApiCall(apiCall, sku, retryCount - 1);
                        }
                    }
                    else
                    {
                        _logger.LogError("Failed to extract resource_id from error message for SKU {Sku}: {ErrorMessage}", sku, errorMessage);
                    }
                }
                _logger.LogError("Error processing product with SKU {Sku}: {ErrorMessage}", sku, ex.Message, ex);
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError("An error occurred for SKU {Sku}: {ErrorMessage}", sku, ex.Message, ex);
                throw;
            }
        }

        private ProductAttribute UpdateAttribute(List<ProductAttribute> existingAttributes, string name, string slug, string option, int id)
        {
            // Updates an attribute by reusing or adding values to existing options
            var existingAttr = existingAttributes?.FirstOrDefault(a => a.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
            return new ProductAttribute
            {
                Id = existingAttr?.Id ?? id,
                Name = name,
                Slug = slug,
                Options = new List<string> { option },
                Position = existingAttr?.Position?.ToString() ?? id.ToString(),
                Visible = existingAttr?.Visible?.ToString().ToLower() ?? "true",
                Variation = existingAttr?.Variation?.ToString().ToLower() ?? "false"
            };
        }

        public class ProductAttributeComparer : IEqualityComparer<ProductAttribute>
        {
            // Compares attributes by name and options to identify duplicates
            public bool Equals(ProductAttribute x, ProductAttribute y)
            {
                if (x == null || y == null)
                    return false;
                return x.Name == y.Name && x.Options.SequenceEqual(y.Options);
            }

            public int GetHashCode(ProductAttribute obj)
            {
                return obj.Name.GetHashCode() ^ obj.Options.GetHashCode();
            }
        }

        private string CreateSlug(string name)
        {
            // Creates a URL-friendly slug by removing special characters and spaces
            if (string.IsNullOrWhiteSpace(name))
                return null;

            name = name
                .Trim()
                .ToLower()
                .Replace("&", "and")
                .Replace("'", "")
                .Replace(".", "")
                .Replace("/", "-")
                .Replace(",", "")
                .Replace("(", "")
                .Replace(")", "");

            name = Regex.Replace(name, @"[\s-]+", "-");
            return name;
        }

        private async Task<ProductCategory> GetOrCreateCategoryAsync(string categoryName, List<ProductCategory> existingCategories)
        {
            // Ensures a category exists by creating it if not found in existing categories
            if (string.IsNullOrWhiteSpace(categoryName)) return null;

            var categoryParts = categoryName.Split(':');
            string childCategoryName = categoryParts[0].Trim();
            string parentCategoryName = categoryParts.Length > 1 ? categoryParts[1].Trim() : null;

            ProductCategory parentCategory = null;
            try
            {
                if (!string.IsNullOrWhiteSpace(parentCategoryName))
                {
                    string parentSlug = CreateCategorySlug(parentCategoryName);
                    parentCategory = existingCategories.FirstOrDefault(c =>
                        c.Slug.Equals(parentSlug, StringComparison.OrdinalIgnoreCase) ||
                        c.Name.Equals(parentCategoryName, StringComparison.OrdinalIgnoreCase));

                    if (parentCategory == null)
                    {
                        parentCategory = await _restApiService.CreateProductCategoryAsync(_restApiSettings, new ProductCategory
                        {
                            Name = parentCategoryName,
                            Slug = parentSlug
                        });
                        existingCategories.Add(parentCategory);
                    }
                }

                string childSlug = CreateCategorySlug(childCategoryName);
                var existingCategory = existingCategories.FirstOrDefault(c =>
                    (c.Slug.Equals(childSlug, StringComparison.OrdinalIgnoreCase) ||
                     c.Name.Equals(childCategoryName, StringComparison.OrdinalIgnoreCase)) &&
                    (parentCategory == null || c.Parent == parentCategory.Id));

                if (existingCategory != null)
                {
                    return existingCategory;
                }

                var newCategory = new ProductCategory
                {
                    Name = childCategoryName,
                    Slug = childSlug,
                    Parent = parentCategory?.Id
                };

                var createdCategory = await _restApiService.CreateProductCategoryAsync(_restApiSettings, newCategory);
                existingCategories.Add(createdCategory);

                return createdCategory;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while creating category {categoryName}: {ex.Message}", ex);
                throw;
            }
        }

        private string CreateCategorySlug(string name)
        {
            // Creates a unique slug for categories
            if (string.IsNullOrWhiteSpace(name))
                return null;

            name = name
                .Trim()
                .ToLower()
                .Replace("&", "and")
                .Replace("/", "-")
                .Replace(",", "")
                .Replace("(", "")
                .Replace(")", "")
                .Replace("'", "")
                .Replace(">", "")
                .Replace("<", "")
                .Replace(".", "");

            name = Regex.Replace(name, @"[\s-]+", "-");
            return name;
        }

        private int GetCategoryIdBySlug(string slug, List<ProductCategory> existingCategories)
        {
            // Retrieves category ID based on slug
            var category = existingCategories.FirstOrDefault(c => c.Slug.Equals(slug, StringComparison.OrdinalIgnoreCase));
            return category?.Id ?? 0;
        }

        List<string> GetUnitsOfMeasurementOptions(List<ExcelProduct> variations)
        {
            // Collects unique units of measurement from variations
            return variations
               .Where(v => !string.IsNullOrWhiteSpace(v.UnitsOfMeasurement))
               .Select(v => v.UnitsOfMeasurement.Trim())
               .Distinct()
               .ToList();
        }

        public List<(string CategoryName, string Slug, int Count)> GetDuplicateCategoryCounts(List<ProductCategory> categories)
        {
            // Counts duplicate categories by name and slug
            return categories
                .GroupBy(c => new { Name = c.Name.ToLower().Trim(), Slug = c.Slug.ToLower().Trim() })
                .Where(g => g.Count() > 1)
                .Select(g => (CategoryName: g.Key.Name, Slug: g.Key.Slug, Count: g.Count()))
                .ToList();
        }

        public async Task DeleteDuplicateCategoriesAsync()
        {
            // Deletes duplicate categories except for the first entry
            List<ProductCategory> existingCategories = await _restApiService.GetProductCategoryAsync(_restApiSettings);

            var duplicateGroups = existingCategories
                .GroupBy(c => c.Name.ToLower())
                .Where(g => g.Count() > 1)
                .ToList();

            if (duplicateGroups.Any())
            {
                var deletionTasks = new List<Task>();
                var semaphore = new SemaphoreSlim(10);

                foreach (var group in duplicateGroups)
                {
                    foreach (var duplicateCategory in group.Skip(1))
                    {
                        await semaphore.WaitAsync();
                        deletionTasks.Add(Task.Run(async () =>
                        {
                            try
                            {
                                bool isDeleted = await _restApiService.DeleteCategoryByIdAsync(_restApiSettings, duplicateCategory.Id);
                                if (isDeleted)
                                {
                                    Console.WriteLine($"Deleted duplicate category: {duplicateCategory.Name} (ID: {duplicateCategory.Id})");
                                }
                                else
                                {
                                    Console.WriteLine($"Failed to delete duplicate category: {duplicateCategory.Name} (ID: {duplicateCategory.Id})");
                                }
                            }
                            finally
                            {
                                semaphore.Release();
                            }
                        }));
                    }
                }
                await Task.WhenAll(deletionTasks);
            }
            else
            {
                Console.WriteLine("No duplicate categories found.");
            }
        }

        #endregion  
    }
}
