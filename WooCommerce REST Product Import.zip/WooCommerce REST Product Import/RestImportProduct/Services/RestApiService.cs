﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using RestImportPorducts.Helpers;
using RestImportPorducts.Models;
using RestImportProduct.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestImportPorducts.Services
{
    public class RestApiService : IRestApiService
    {
        private readonly ILogger<ProductOrchestrationService> _logger;
        private readonly RestApiSettings _apiSettings;
        private readonly ConcurrentDictionary<string, SemaphoreSlim> _semaphores;

        public RestApiService(ILogger<ProductOrchestrationService> logger, RestApiSettings apiSettings)
        {
            _logger = logger;
            _apiSettings = apiSettings;
            _semaphores = new ConcurrentDictionary<string, SemaphoreSlim>();
        }
        private HttpClient CreateHttpClient(RestApiSettings apiSettings)
        {
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
            };

            var client = new HttpClient(handler)
            {
                BaseAddress = new Uri(apiSettings.BaseUrl),
                Timeout = TimeSpan.FromMinutes(10)
            };
            client.DefaultRequestHeaders.Add("ApiKey", apiSettings.ApiKey);

            return client;
        }

        // POST Product 
        public async Task<Product> PostProductAsync(RestApiSettings apiSettings, Product product)
        {
            if (product == null)
                throw new ArgumentNullException(nameof(product), "Product cannot be null.");

            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";

            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                var content = new StringContent(JsonConvert.SerializeObject(product), Encoding.UTF8, "application/json");
                var jsonLoad=JsonConvert.SerializeObject(product);
                using var response = await httpClient.PostAsync(requestUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to create product. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}");
                    throw new HttpRequestException($"{apiSettings.BaseUrl} :Error creating product: {responseContent}");
                }

                var responseData = await response.Content.ReadAsStringAsync();
                _logger.LogInformation($"{apiSettings.BaseUrl} :Product created successfully. Status Code: {response.StatusCode}");

                return JsonConvert.DeserializeObject<Product>(responseData);
            }
            finally
            {
                semaphore.Release();
            }
        }

        // Update Product
        public async Task<Product> UpdateProductAsync(RestApiSettings apiSettings, string productId, Product updatedProduct)
        {
            if (string.IsNullOrWhiteSpace(productId))
                throw new ArgumentNullException(nameof(productId), "Product ID cannot be null or empty.");

            if (updatedProduct == null)
                throw new ArgumentNullException(nameof(updatedProduct), "Updated product cannot be null.");

            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/{productId}?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";

            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                var content = new StringContent(JsonConvert.SerializeObject(updatedProduct), Encoding.UTF8, "application/json");
                using var response = await httpClient.PutAsync(requestUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to update product. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Response: {responseContent}");
                    throw new HttpRequestException($"{apiSettings.BaseUrl} :Error updating product: {response.ReasonPhrase}");
                }

                var responseData = await response.Content.ReadAsStringAsync();
                _logger.LogInformation($"{apiSettings.BaseUrl} :Product {productId} updated successfully. Status Code: {response.StatusCode}");

                return JsonConvert.DeserializeObject<Product>(responseData);
            }
            finally
            {
                semaphore.Release();
            }
        }


        // Get Products
        public async Task<(Dictionary<string, Product> SimpleProducts, Dictionary<string, ProductWithVariations> VariableProducts)> LoadExistingProductsAndVariationsAsync(RestApiSettings apiSettings)
        {
            var simpleProducts = new Dictionary<string, Product>();
            var variableProducts = new ConcurrentDictionary<string, ProductWithVariations>();
            int page = 1;
            bool hasMore = true;
            var variationFetchTasks = new List<Task>();

            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            while (hasMore)
            {
                await semaphore.WaitAsync();
                try
                {
                    var currentProducts = await FetchProductPageAsync(apiSettings, page);
                    _logger.LogInformation($"{apiSettings.BaseUrl} :Fetching product page: {page}");

                    if (currentProducts.Count > 0)
                    {
                        foreach (var product in currentProducts)
                        {
                            if (!string.IsNullOrEmpty(product.Sku))
                            {
                                if (product.Type == "simple")
                                {
                                    simpleProducts[product.Sku] = product;
                                }
                                else if (product.Type == "variable")
                                {
                                    var productWithVariations = new ProductWithVariations
                                    {
                                        Product = product,
                                        Variations = new List<ProductVariation>()
                                    };

                                    variationFetchTasks.Add(FetchAndStoreVariationsAsync(apiSettings, productWithVariations, variableProducts));
                                }
                            }
                        }
                    }

                    if (currentProducts.Count < 100)
                    {
                        hasMore = false;
                    }

                    page++;
                }
                finally
                {
                    semaphore.Release();
                }
            }

            await Task.WhenAll(variationFetchTasks);
            return (simpleProducts, variableProducts.ToDictionary(kv => kv.Key, kv => kv.Value));
        }

        // Fetch and store variations for each variable product in parallel
        private async Task FetchAndStoreVariationsAsync(RestApiSettings apiSettings, ProductWithVariations productWithVariations, ConcurrentDictionary<string, ProductWithVariations> variableProducts)
        {
            var variations = await FetchProductVariationsAsync(apiSettings, productWithVariations.Product.Id.ToString());
            if (variations.Any())
            {
                productWithVariations.Variations.AddRange(variations);
            }

            variableProducts[productWithVariations.Product.Sku] = productWithVariations;
        }

        // Fetch product variations
        private async Task<List<ProductVariation>> FetchProductVariationsAsync(RestApiSettings apiSettings, string parentProductId)
        {
            var variations = new List<ProductVariation>();
            int page = 1;
            bool hasMore = true;

            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            while (hasMore)
            {
                await semaphore.WaitAsync();
                try
                {
                    var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/{parentProductId}/variations?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}&per_page=100&page={page}";
                    using var httpClient = CreateHttpClient(apiSettings);
                    var response = await httpClient.GetAsync(requestUrl);

                    if (!response.IsSuccessStatusCode)
                    {
                        var errorResponse = await response.Content.ReadAsStringAsync();
                        throw new Exception($"{apiSettings.BaseUrl} :Failed to fetch variations for product {parentProductId}. Error: {errorResponse}");
                    }

                    var responseData = await response.Content.ReadAsStringAsync();
                    var currentVariations = JsonConvert.DeserializeObject<List<ProductVariation>>(responseData);

                    if (currentVariations.Count > 0)
                    {
                        variations.AddRange(currentVariations);
                    }

                    if (currentVariations.Count < 100)
                    {
                        hasMore = false;
                    }

                    page++;
                }
                finally
                {
                    semaphore.Release();
                }
            }

            return variations;
        }


        // Fetch a page of products
        private async Task<List<Product>> FetchProductPageAsync(RestApiSettings apiSettings, int page)
        {
            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}&per_page=100&page={page}";

            using var httpClient = CreateHttpClient(apiSettings);
            var response = await httpClient.GetAsync(requestUrl);

            if (!response.IsSuccessStatusCode)
            {
                var errorResponse = await response.Content.ReadAsStringAsync();
                throw new Exception($"{apiSettings.BaseUrl} :Failed to fetch products on page {page}. Error: {errorResponse}");
            }

            var responseData = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<List<Product>>(responseData) ?? new List<Product>();
        }

        //GetAllCategories
        public async Task<List<ProductCategory>> GetProductCategoryAsync(RestApiSettings apiSettings)
        {
            var categories = new List<ProductCategory>();
            int page = 1;

            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);

                while (true)
                {
                    var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/categories?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}&per_page=100&page={page}";
                    using var response = await httpClient.GetAsync(requestUrl);

                    if (!response.IsSuccessStatusCode)
                    {
                        var responseContent = await response.Content.ReadAsStringAsync();
                        _logger.LogError($"{apiSettings.BaseUrl} :Failed to fetch product categories. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Response: {responseContent}");
                        throw new HttpRequestException($"{apiSettings.BaseUrl} :Error while fetching categories: {response.ReasonPhrase}");
                    }

                    var responseData = await response.Content.ReadAsStringAsync();
                    var currentCategories = JsonConvert.DeserializeObject<List<ProductCategory>>(responseData);

                    if (currentCategories == null || currentCategories.Count == 0)
                        break;

                    categories.AddRange(currentCategories);

                    if (currentCategories.Count < 100)
                        break;

                    page++;
                }
            }
            finally
            {
                semaphore.Release();
            }

            return categories;
        }

        //InsertCategorie
        public async Task<ProductCategory> CreateProductCategoryAsync(RestApiSettings apiSettings, ProductCategory newCategory)
        {
            if (newCategory == null)
                throw new ArgumentNullException(nameof(newCategory), "New category cannot be null.");

            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/categories?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";
            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                var content = new StringContent(JsonConvert.SerializeObject(newCategory), Encoding.UTF8, "application/json");
                var response = await httpClient.PostAsync(requestUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to create product category. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}");
                    throw new HttpRequestException($"{apiSettings.BaseUrl} :Error while creating category: {response.ReasonPhrase}");
                }

                var responseData = await response.Content.ReadAsStringAsync();
                _logger.LogInformation($"{apiSettings.BaseUrl} :Product category created successfully. Status Code: {response.StatusCode}");
                return JsonConvert.DeserializeObject<ProductCategory>(responseData);
            }
            finally
            {
                semaphore.Release();
            }
        }


        // POST Variation
        public async Task<ProductVariation> PostProductVariationAsync(RestApiSettings apiSettings, string productId, ProductVariation variation)
        {
            if (string.IsNullOrWhiteSpace(productId))
                throw new ArgumentException("Product ID cannot be null or empty.", nameof(productId));

            if (variation == null)
                throw new ArgumentNullException(nameof(variation), "Product variation cannot be null.");

            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/{productId}/variations?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";
            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                var content = new StringContent(JsonConvert.SerializeObject(variation), Encoding.UTF8, "application/json");
                using var response = await httpClient.PostAsync(requestUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to create product variation. Product ID: {productId}, Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Response: {responseContent}");
                    throw new HttpRequestException($"{apiSettings.BaseUrl} :Error creating product variation: {response.ReasonPhrase}");
                }

                var responseData = await response.Content.ReadAsStringAsync();
                _logger.LogInformation($"{apiSettings.BaseUrl} :Product variation created successfully. Product ID: {productId}, Status Code: {response.StatusCode}");
                return JsonConvert.DeserializeObject<ProductVariation>(responseData);
            }
            finally
            {
                semaphore.Release();
            }
        }

        //Update Product
        public async Task<ProductVariation> UpdateProductVariationAsync(RestApiSettings apiSettings, string productId, string variationId, ProductVariation updatedVariation)
        {
            if (string.IsNullOrWhiteSpace(productId))
                throw new ArgumentException("Product ID cannot be null or empty.", nameof(productId));

            if (string.IsNullOrWhiteSpace(variationId))
                throw new ArgumentException("Variation ID cannot be null or empty.", nameof(variationId));

            if (updatedVariation == null)
                throw new ArgumentNullException(nameof(updatedVariation), "Updated variation cannot be null.");

            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/{productId}/variations/{variationId}?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";
            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                var content = new StringContent(JsonConvert.SerializeObject(updatedVariation), Encoding.UTF8, "application/json");
                using var response = await httpClient.PutAsync(requestUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to update product variation. Product ID: {productId}, Variation ID: {variationId}, Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Response: {responseContent}");
                    throw new HttpRequestException($"{apiSettings.BaseUrl} :Error updating product variation: {response.ReasonPhrase}");
                }

                var responseData = await response.Content.ReadAsStringAsync();
                _logger.LogInformation($"{apiSettings.BaseUrl} :Product variation updated successfully. Product ID: {productId}, Variation ID: {variationId}, Status Code: {response.StatusCode}");
                return JsonConvert.DeserializeObject<ProductVariation>(responseData);
            }
            finally
            {
                semaphore.Release();
            }
        }

        //Delete Categorie
        public async Task<bool> DeleteCategoryByIdAsync(RestApiSettings apiSettings, int categoryId)
        {
            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/categories/{categoryId}?force=true&consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";
            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                var response = await httpClient.DeleteAsync(requestUrl);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to delete category. Category ID: {categoryId}, Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Response: {responseContent}");
                    return false;
                }

                _logger.LogInformation($"{apiSettings.BaseUrl} :Category deleted successfully. Category ID: {categoryId}");
                return true;
            }
            finally
            {
                semaphore.Release();
            }
        }

        // Batch Create/Update Products
        public async Task BatchCreateOrUpdateProductsAsync(RestApiSettings apiSettings, BatchProductRequest batchRequest)
        {
            if (batchRequest == null)
                throw new ArgumentNullException(nameof(batchRequest), "Batch request cannot be null.");

            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/batch?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";
            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                var content = new StringContent(JsonConvert.SerializeObject(batchRequest), Encoding.UTF8, "application/json");
                using var response = await httpClient.PostAsync(requestUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to batch create/update products. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Response: {responseContent}");
                    throw new HttpRequestException($"{apiSettings.BaseUrl} :Error in batch create/update products: {response.ReasonPhrase}");
                }

                var responseData = await response.Content.ReadAsStringAsync();
                _logger.LogInformation($"{apiSettings.BaseUrl} :Batch create/update products successful. Status Code: {response.StatusCode}");
                _logger.LogDebug($"{apiSettings.BaseUrl} :Batch response data: {responseData}");
            }
            finally
            {
                semaphore.Release();
            }
        }

        // Batch Update Variations
public async Task UpdateVariationProductOnBatchAsync(RestApiSettings apiSettings, string productId, List<ProductVariation> variations)
{
    if (string.IsNullOrWhiteSpace(productId))
        throw new ArgumentException("Product ID cannot be null or empty.", nameof(productId));

    if (variations == null || !variations.Any())
        throw new ArgumentNullException(nameof(variations), "Variations list cannot be null or empty.");

    var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/{productId}/variations/batch?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";
    var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

    await semaphore.WaitAsync();
    try
    {
        using var httpClient = CreateHttpClient(apiSettings);
        var batchUpdateRequest = new { update = variations };
        var content = new StringContent(JsonConvert.SerializeObject(batchUpdateRequest), Encoding.UTF8, "application/json");

        using var response = await httpClient.PostAsync(requestUrl, content);

        if (!response.IsSuccessStatusCode)
        {
            var responseContent = await response.Content.ReadAsStringAsync();
            _logger.LogError($"{apiSettings.BaseUrl} :Failed to batch update variations for Product ID: {productId}. Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Response: {responseContent}");
            throw new HttpRequestException($"{apiSettings.BaseUrl} :Error in batch update variations for product ID: {productId}, {response.ReasonPhrase}");
        }

        var responseData = await response.Content.ReadAsStringAsync();
        _logger.LogInformation($"{apiSettings.BaseUrl} :Batch update variations successful for Product ID: {productId}. Status Code: {response.StatusCode}");
        _logger.LogDebug($"{apiSettings.BaseUrl} :Batch update response data: {responseData}");
    }
    finally
    {
        semaphore.Release();
    }
}

        //DeleteProduct
        public async Task<bool> DeleteProductAsync(RestApiSettings apiSettings, string productId, bool force = false)
        {
            if (string.IsNullOrWhiteSpace(productId))
                throw new ArgumentException("Product ID cannot be null or empty.", nameof(productId));

            var forceQuery = force ? "&force=true" : string.Empty;
            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wc/v3/products/{productId}?consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}{forceQuery}";
            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                var response = await httpClient.DeleteAsync(requestUrl);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to delete product. Product ID: {productId}, Status Code: {response.StatusCode}, Reason: {response.ReasonPhrase}, Response: {responseContent}");
                    throw new HttpRequestException($"{apiSettings.BaseUrl} :Error deleting product: {response.ReasonPhrase}");
                }

                _logger.LogInformation($"{apiSettings.BaseUrl} :Product deleted successfully. Product ID: {productId}");
                return true;
            }
            finally
            {
                semaphore.Release();
            }
        }

        public async Task<MediaItem> GetExistingImageUrl(RestApiSettings apiSettings, string imageName)
        {
            var requestUrl = $"{apiSettings.BaseUrl}/wp-json/wp/v2/media?search={imageName}&media_type=image&per_page=1&consumer_key={apiSettings.ApiKey}&consumer_secret={apiSettings.ApiSecret}";
            var semaphore = _semaphores.GetOrAdd(apiSettings.BaseUrl, _ => new SemaphoreSlim(apiSettings.SemaphoreSlimSpeed));

            await semaphore.WaitAsync();
            try
            {
                using var httpClient = CreateHttpClient(apiSettings);
                using var response = await httpClient.GetAsync(requestUrl);

                if (!response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    _logger.LogError($"{apiSettings.BaseUrl} :Failed to search media library for image {imageName}. Status Code: {response.StatusCode}, Response: {responseContent}");
                    return null;
                }

                var responseData = await response.Content.ReadAsStringAsync();
                List<MediaItem> mediaItems = JsonConvert.DeserializeObject<List<MediaItem>>(responseData);

                return mediaItems?.FirstOrDefault();
            }
            catch (Exception ex)
            {
                _logger.LogError($"{apiSettings.BaseUrl} :An error occurred while searching for image {imageName}: {ex.Message}");
                return null;
            }
            finally
            {
                semaphore.Release();
            }
        }

    }
}
