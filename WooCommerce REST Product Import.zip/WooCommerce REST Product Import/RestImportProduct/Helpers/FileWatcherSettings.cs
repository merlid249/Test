﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestImportPorducts.Helpers
{
    public class FileWatcherSettings
    {
        public string DirectoryPath { get; set; }
        public string BackupDirectoryPath { get; set; }
    }

    public class RestApiSettings
    {
        public int SemaphoreSlimSpeed { get; set; }
        public string BaseUrl { get; set; }
        public string ApiKey { get; set; }
        public string ApiSecret { get; set; }
        public decimal PriceIncreasePercentage { get; set; }
        public string ImagesUrl { get; set; }
        public string ProductSheet { get; set; }
    }
}
