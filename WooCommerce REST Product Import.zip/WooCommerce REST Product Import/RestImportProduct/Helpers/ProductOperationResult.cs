﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestImportPorducts.Helpers
{
    public class ProductOperationResult
    {
        public string SKU { get; set; }
        public string ActionType { get; set; }  
        public string Status { get; set; } 
        public string ErrorMessage { get; set; }  
    }

}
