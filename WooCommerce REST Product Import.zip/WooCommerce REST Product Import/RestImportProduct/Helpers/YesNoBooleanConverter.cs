﻿using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System;

namespace RestImportPorducts.Helpers
{
    public class YesNoBooleanConverter : BooleanConverter
    {
        public override object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return null;
            }

            text = text.Trim().ToLower();

            if (text == "yes" || text == "true" || text == "y" || text == "1" || text == "instock")
            {
                return true;
            }

            if (text == "no" || text == "false" || text == "n" || text == "0" || text == "outofstock")
            {
                return false;
            }

            throw new TypeConverterException(this, memberMapData, text, row.Context, $"Invalid boolean value: {text}");
        }
    }
}
