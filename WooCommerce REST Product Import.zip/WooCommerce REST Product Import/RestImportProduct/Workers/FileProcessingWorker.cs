﻿using Microsoft.Extensions.Options;
using RestImportPorducts.Helpers;
using RestImportPorducts.Services;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RestImportPorducts.Workers
{
    public class FileProcessingWorker : BackgroundService
    {
        private readonly ILogger<FileProcessingWorker> _logger;
        private readonly IExcelProcessingService _excelProcessingService;
        private readonly List<IProductOrchestrationService> _productOrchestrationServices;
        private readonly string _folderPath;
        private readonly string _backupFolderPath;
        private FileSystemWatcher _watcher;

        public FileProcessingWorker(
            ILogger<FileProcessingWorker> logger,
            IExcelProcessingService excelProcessingService,
            IOptions<FileWatcherSettings> fileWatcherSettings,
            IEnumerable<IProductOrchestrationService> productOrchestrationServices)
        {
            _logger = logger;
            _excelProcessingService = excelProcessingService;
            _productOrchestrationServices = productOrchestrationServices.ToList();
            _folderPath = fileWatcherSettings.Value.DirectoryPath;
            _backupFolderPath = fileWatcherSettings.Value.BackupDirectoryPath;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation($"Watching folder: {_folderPath}");

            Directory.CreateDirectory(_folderPath);
            Directory.CreateDirectory(_backupFolderPath);

            _watcher = new FileSystemWatcher
            {
                Path = _folderPath,
                Filter = "*.csv",
                NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite
            };
            _watcher.Created += async (sender, e) => await OnCreatedAsync(e);
            _watcher.EnableRaisingEvents = true;

            _logger.LogInformation("File watcher started...");
            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(1000, stoppingToken);
            }
        }

        private async Task OnCreatedAsync(FileSystemEventArgs e)
        {
            _logger.LogInformation($"File detected: {e.FullPath}");
            WaitForFile(e.FullPath);

            try
            {
                var (simpleProducts, variableProducts) = await _excelProcessingService.ProcessCsvFile(e.FullPath);
                _logger.LogInformation($"CSV file processed: {e.FullPath}. Simple products: {simpleProducts.Count}, Variations: {variableProducts.Count}");

                // Run OrchestrateProductsAsync in parallel for each ProductOrchestrationService
                var tasks = _productOrchestrationServices.Select(service =>
                    service.OrchestrateProductsAsync(simpleProducts, variableProducts)).ToList();

                await Task.WhenAll(tasks);
                _logger.LogInformation("Product orchestration completed for all directions.");

                var backupFilePath = CreateBackupFilePath(e.Name);
                File.Move(e.FullPath, backupFilePath);
                _logger.LogInformation($"File moved to backup: {backupFilePath}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error processing file {e.FullPath}: {ex.Message}");
            }
        }

        private void WaitForFile(string filePath)
        {
            const int maxRetries = 10;
            const int delayMilliseconds = 500;
            int retryCount = 0;

            while (retryCount < maxRetries)
            {
                try
                {
                    using (FileStream stream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.None))
                    {
                        stream.Close();
                    }
                    return;
                }
                catch (IOException)
                {
                    Thread.Sleep(delayMilliseconds);
                    retryCount++;
                }
            }
        }

        private string CreateBackupFilePath(string fileName)
        {
            var fileExtension = Path.GetExtension(fileName);
            var baseFileName = Path.GetFileNameWithoutExtension(fileName);
            var currentDate = DateTime.Now.ToString("yyyyMMdd-HHmmss");
            var newFileName = $"{baseFileName}_{currentDate}{fileExtension}";
            return Path.Combine(_backupFolderPath, newFileName);
        }

        public override Task StopAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("File watcher stopping...");

            if (_watcher != null)
            {
                _watcher.EnableRaisingEvents = false;
                _watcher.Dispose();
            }

            return base.StopAsync(stoppingToken);
        }
    }
}
