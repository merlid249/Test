﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestImportProduct.Models
{
    public class MediaItem
    {
        [JsonProperty("id")]
        public int Id { get; set; } 

        [JsonProperty("title")]
        public Title Title { get; set; }

        [JsonProperty("slug")]
        public string Slug { get; set; }

        [JsonProperty("date")]
        public string? Date { get; set; }

        [JsonProperty("date_gmt")]
        public string? DateGmt { get; set; }

        [JsonProperty("modified")]
        public string? Modified { get; set; }

        [JsonProperty("modified_gmt")]
        public string? ModifiedGmt { get; set; }
         
        [JsonProperty("alt_text")]
        public string? Alt { get; set; }

        [JsonProperty("guid")]

        public GuIdLink? GuIdLink { get; set; } 
    }
    public class GuIdLink 
    {
        [JsonProperty("rendered")]
        public string Rendered { get; set; }
    }
    public class Title
    {
        [JsonProperty("rendered")]
        public string Rendered { get; set; }
    }
}
