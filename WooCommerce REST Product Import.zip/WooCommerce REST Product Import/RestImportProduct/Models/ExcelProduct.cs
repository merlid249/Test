﻿using CsvHelper.Configuration.Attributes;
using Microsoft.Extensions.Options;
using RestImportPorducts.Helpers;
using System.Collections.Generic;

namespace RestImportPorducts.Models
{
    public class ExcelProduct
    { 

        [Name("Type")]
        public string Type { get; set; }

        [Name("Parent")]
        public string? Parent { get; set; }

        [Name("SKU")]
        public string SKU { get; set; }

        [Name("Name")]
        public string Name { get; set; }

        [Name("Is featured?")]
        public string IsFeatured { get; set; }  

        [Name("Visibility in catalog")]
        public string VisibilityInCatalog { get; set; }

        [Name("Description")]
        public string Description { get; set; }

        [Name("Tax status")]
        public string TaxStatus { get; set; }

        [Name("Tax class")]
        public string TaxClass { get; set; }

        [Name("Manage Stock")]
        public string ManageStock { get; set; }

        [Name("In stock?")]
        public string InStock { get; set; }

        [Name("Stock")]
        public decimal? Stock { get; set; }

        [Name("Regular price")]
        public string? RegularPrice { get; set; }

        [Name("Major Categorie")]
        public string MajorCategory { get; set; }

        [Name("Minor Categorie")]
        public string MinorCategory { get; set; }

        [Name("Images")]
        public string Images { get; set; }

        [Name("Manufacturer")]
        public string Manufacturer { get; set; }

        [Name("Units of Measurement")]
        public string UnitsOfMeasurement { get; set; }

        [Name("UNSPSC")]
        public string UNSPSC { get; set; }

        [Name("Product Specification Sheet")]
        public string ProductSpecificationSheet { get; set; }

        [Name("Application")]
        public string Application { get; set; }

        [Name("For Use With")]
        public string ForUseWith { get; set; }

        [Name("HCPCS")]
        public string HCPCS { get; set; }

        [Name("Is Active Vendor")]
        public string IsActiveVendor { get; set; }

        [Name("Is DSCSA")]
        public string IsDSCSA { get; set; }

        [Name("Is Discontinued")]
        public string IsDiscontinued { get; set; }

        [Name("Is Medical Device")]
        public string IsMedicalDevice { get; set; }

        [Name("Lot Tracking Flag")]
        public string LotTrackingFlag { get; set; }

        [Name("Material")]
        public string Material { get; set; }

        [Name("Number per Pack")]
        public string NumberPerPack { get; set; }

        [Name("On Allocation")]
        public string OnAllocation { get; set; }

        [Name("Specifications")]
        public string Specifications { get; set; }

        [Name("Supplier ID")]
        public string SupplierID { get; set; }

        [Name("Type")]
        public string ProductType { get; set; }

        [Name("Volume")]
        public string Volume { get; set; }

        [Name("Dimensions")]
        public string Dimensions { get; set; }

        [Name("Color")]
        public string Color { get; set; }

        [Name("Container Type")]
        public string ContainerType { get; set; }

        [Name("Dosage Form")]
        public string DosageForm { get; set; }

        [Name("Generic Drug Code")]
        public string GenericDrugCode { get; set; }

        [Name("Generic Drug Name")]
        public string GenericDrugName { get; set; }

        [Name("NDC Number")]
        public string NDCNumber { get; set; }

        [Name("Product Dating")]
        public string ProductDating { get; set; }

        [Name("Sterility")]
        public string Sterility { get; set; }

        [Name("Strength")]
        public string Strength { get; set; }

        [Name("Latex Free Indicator")]
        public string LatexFreeIndicator { get; set; }

        [Name("Length")]
        public string Length { get; set; }

        [Name("Ply")]
        public string Ply { get; set; }

        [Name("Shape")]
        public string Shape { get; set; }

        [Name("Usage")]
        public string Usage { get; set; }

        [Name("IsRetail")]
        public string IsRetail { get; set; }

        public List<ExcelProduct> Variations { get; set; } = new List<ExcelProduct>();

         
    }
}
