﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace RestImportPorducts.Models
{
    public class ProductVariation
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public int? id { get; set; }

        [JsonProperty("sku", NullValueHandling = NullValueHandling.Ignore)]
        public string sku { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string name { get; set; }

        [JsonProperty("parentId", NullValueHandling = NullValueHandling.Ignore)]
        public int? parentId { get; set; }

        [JsonProperty("description", NullValueHandling = NullValueHandling.Ignore)]
        public string description { get; set; }

        [JsonProperty("price", NullValueHandling = NullValueHandling.Ignore)]
        public string price { get; set; }

        [JsonProperty("regular_price", NullValueHandling = NullValueHandling.Ignore)]
        public string regularPrice { get; set; }

        [JsonProperty("sale_price", NullValueHandling = NullValueHandling.Ignore)]
        public string salePrice { get; set; }

        [JsonProperty("manage_stock", NullValueHandling = NullValueHandling.Ignore)]
        public bool? manageStock { get; set; }

        [JsonProperty("stock_quantity", NullValueHandling = NullValueHandling.Ignore)]
        public int? stockQuantity { get; set; }

        [JsonProperty("stock_status", NullValueHandling = NullValueHandling.Ignore)]
        public string stockStatus { get; set; }

        [JsonProperty("permalink", NullValueHandling = NullValueHandling.Ignore)]
        public string permalink { get; set; }

        [JsonProperty("image", NullValueHandling = NullValueHandling.Ignore)]
        public ProductImage image { get; set; }

        [JsonProperty("attributes", NullValueHandling = NullValueHandling.Ignore)]
        public List<ProductAttribute> attributes { get; set; }

        [JsonProperty("meta_data", NullValueHandling = NullValueHandling.Ignore)]
        public List<ProductMetaData> metaData { get; set; }

        // Inner classes
        public class ProductImage
        {
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public int id { get; set; }

            [JsonProperty("src", NullValueHandling = NullValueHandling.Ignore)]
            public string src { get; set; }

            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public string name { get; set; }

            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public string alt { get; set; }
        }

        public class ProductAttribute
        {
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public int id { get; set; }

            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public string name { get; set; }

            [JsonProperty("option", NullValueHandling = NullValueHandling.Ignore)]
            public string option { get; set; }
        }

        public class ProductMetaData
        {
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public int id { get; set; }

            [JsonProperty("key", NullValueHandling = NullValueHandling.Ignore)]
            public string key { get; set; }

            [JsonProperty("value", NullValueHandling = NullValueHandling.Ignore)]
            public string value { get; set; }
        }
    }
}
