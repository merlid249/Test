﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestImportPorducts.Models
{
    public class BatchProductRequest
    {
        public List<Product2> Create { get; set; }
        public List<Product2> Update { get; set; }
        public List<int> Delete { get; set; } // If you want to delete products as well
    }

    public class Product2
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Slug { get; set; }
        public string Permalink { get; set; }
        public string Description { get; set; }
        public string Sku { get; set; }
        public string Price { get; set; }
        public string RegularPrice { get; set; }
        public string StockStatus { get; set; }
        public List<ProductCategory> Categories { get; set; }
     }

    public class ProductCategory
    {
        public int Id { get; set; }
    }

}
