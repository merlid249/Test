﻿using Newtonsoft.Json;

public class Product
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("slug")]
    public string Slug { get; set; }

    [JsonProperty("permalink")]
    public string Permalink { get; set; }

    [JsonProperty("date_created")]
    public DateTime DateCreated { get; set; }

    [JsonProperty("date_modified")]
    public DateTime DateModified { get; set; }

    [JsonProperty("type")]
    public string Type { get; set; }

    [JsonProperty("status")]
    public string Status { get; set; }

    [JsonProperty("featured")]
    public bool Featured { get; set; } 

    [JsonProperty("description")]
    public string Description { get; set; }

    [JsonProperty("short_description")]
    public string ShortDescription { get; set; }

    [JsonProperty("sku")]
    public string Sku { get; set; }

    [JsonProperty("price")]
    public string? Price { get; set; }

    [JsonProperty("regular_price")]
    public string? RegularPrice { get; set; }

    [JsonProperty("sale_price")]
    public string? SalePrice { get; set; }

    [JsonProperty("on_sale")]
    public bool? OnSale { get; set; }

    [JsonProperty("purchasable")]
    public bool Purchasable { get; set; }

    [JsonProperty("virtual")]
    public bool Virtual { get; set; }

    [JsonProperty("downloadable")]
    public bool Downloadable { get; set; }

    [JsonProperty("manage_stock")]
    public bool? ManageStock { get; set; }

    [JsonProperty("stock_quantity")]
    public int? StockQuantity { get; set; }

    [JsonProperty("stock_status")]
    public string StockStatus { get; set; }

    [JsonProperty("shipping_required")]
    public bool ShippingRequired { get; set; }

    [JsonProperty("shipping_taxable")]
    public bool ShippingTaxable { get; set; }

    [JsonProperty("categories")]
    public List<ProductCategory> Categories { get; set; }

    [JsonProperty("attributes")]
    public List<ProductAttribute> Attributes { get; set; }

    [JsonProperty("images")]
    public List<ProductImage> Images { get; set; }

    [JsonProperty("variations")]
    public List<int> Variations { get; set; }
}

public class ProductCategory
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("slug")]
    public string Slug { get; set; }

    [JsonProperty("parent")]
    public int? Parent { get; set; }

    [JsonProperty("description")]
    public string Description { get; set; }

    [JsonProperty("display")]
    public string Display { get; set; }

    [JsonProperty("image")]
    public string Image { get; set; }

}

public class ProductAttribute
{
    [JsonProperty("id")]
    public int Id { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("slug")]
    public string Slug { get; set; }

    [JsonProperty("position")]
    public string Position { get; set; }

    [JsonProperty("visible")]
    public string Visible { get; set; }

    [JsonProperty("variation")]
    public string Variation { get; set; } 
 
    [JsonProperty("options")]
    public List<string> Options { get; set; }
}

public class ProductImage
{
    [JsonProperty("id", NullValueHandling = NullValueHandling.Ignore)]
     public int? Id { get; set; }

    [JsonProperty("date_created")]
    public string? DateCreated { get; set; }

    [JsonProperty("date_created_gmt")]
    public string? DateCreatedGmt { get; set; }

    [JsonProperty("date_modified")]
    public string? DateModified { get; set; }

    [JsonProperty("date_modified_gmt")]
    public string? DateModifiedGmt { get; set; }

    [JsonProperty("src")]
    public string Src { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("alt")]
    public string? Alt { get; set; }
}
