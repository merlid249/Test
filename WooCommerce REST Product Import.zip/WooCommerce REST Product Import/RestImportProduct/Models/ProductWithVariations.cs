﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestImportPorducts.Models
{
    public class ProductWithVariations
    {
        public Product Product { get; set; }
        public List<ProductVariation> Variations { get; set; } = new List<ProductVariation>();
    }
}
