using Microsoft.Extensions.Options;
using RestImportPorducts.Helpers;
using RestImportPorducts.Services;
using RestImportPorducts.Workers;
using Serilog;
using System.Net;

public class Program
{
    public static void Main(string[] args)
    {
        // Configure Serilog
        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.Console()
            .WriteTo.File("Logs/log-.txt", rollingInterval: RollingInterval.Day)
            .CreateLogger();

        try
        {
            Log.Information("Starting up the application");
            CreateHostBuilder(args).Build().Run();
        }
        catch (Exception ex)
        {
            Log.Fatal(ex, "The application failed to start correctly");
        }
        finally
        {
            Log.CloseAndFlush();
        }

        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
    }

    public static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .UseSerilog()
            .ConfigureServices((hostContext, services) =>
            {
                IConfiguration configuration = hostContext.Configuration;

                // Configure file watcher settings
                services.Configure<FileWatcherSettings>(configuration.GetSection("FileWatcher"));

                // Retrieve the list of RestApiSettings and register each as a separate service instance
                var restApiSettingsList = configuration.GetSection("RestApiSettingsList").Get<List<RestApiSettings>>();

                foreach (var apiSettings in restApiSettingsList)
                {
                    services.AddSingleton<IRestApiService>(sp =>
                    {
                        var logger = sp.GetRequiredService<ILogger<ProductOrchestrationService>>();
                        return new RestApiService(logger, apiSettings);
                    });

                    services.AddTransient<IProductOrchestrationService>(sp =>
                    {
                        var logger = sp.GetRequiredService<ILogger<ProductOrchestrationService>>();
                        var apiService = sp.GetRequiredService<IRestApiService>();
                        return new ProductOrchestrationService(apiService, logger, Options.Create(apiSettings));
                    });
                }

                // Register the ExcelProcessingService as singleton
                services.AddSingleton<IExcelProcessingService, ExcelProcessingService>();

                // Register FileProcessingWorker as a hosted service
                services.AddHostedService<FileProcessingWorker>();
            });
}
